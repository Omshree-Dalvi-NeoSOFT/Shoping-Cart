export const inCart = (state) => {
    return state.inCart;
}
